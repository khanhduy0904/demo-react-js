import React from "react";
// import Header from "./header";
// import Footer from "./footer";
import "./App.css";
import Home from "./exercise-2/Home";
// import Home from "./exercise-1/Home";

function App() {
  return (
    <div className="App">
      {/* <Header />
      <Footer /> */}
      {/* <Home /> */}
      <Home />
    </div>
  );
}

export default App;
