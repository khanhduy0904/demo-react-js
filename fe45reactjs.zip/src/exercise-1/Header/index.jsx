import React, { Component } from "react";
import "./style.css";

class Header extends Component {
  render() {
    return <div className="ex1-header">Header</div>;
  }
}

export default Header;
