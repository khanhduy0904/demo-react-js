import React, { Component } from "react";
import "./style.css";

class Sidebar extends Component {
  render() {
    return <div className="ex1-sidebar">Sidebar</div>;
  }
}

export default Sidebar;