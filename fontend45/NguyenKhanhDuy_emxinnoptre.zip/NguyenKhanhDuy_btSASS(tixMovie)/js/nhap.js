
$(".slider-nav").slick({
  autoplay: false,
  slidesToShow: 6,
  slidesToScroll: 1,
  //asNavFor: ".slider-for",
  dots: true,
  focusOnSelect: true,
});
